# Návod: karty do appky pomocí AI

Appka Poznávačka umí načíst kvízové karty na **cokoli** (značky, slovíčka, hlavní města, hrady, rostliny, historii…).
Ke každé kartě se samo najde obrázek na Wikipedii a appka se ptá „co to je?“.

## Jak na to (3 kroky)
1. V appce otevři záložku **🧩 Karty**, napiš téma a klepni na **📋 Zkopírovat zadání pro AI**.
   (Nebo zkopíruj text z oddílu „ZADÁNÍ PRO AI“ níže a v řádku TÉMA nahraď `[SEM DOPLŇ TÉMA]`.)
2. Vlož zadání do ChatGPT, Claude, Gemini… a odešli. AI vrátí JSON.
3. Celou odpověď AI vlož do pole **Odpověď od AI (JSON)** a klepni na **⬆ Importovat karty**.
   Nevadí, když je JSON v bloku ```json nebo má text okolo. Appka ho z odpovědi vytáhne.

Appka napíše, kolik karet přidala, a u vynechaných uvede proč (např. „#5: chybí odpověď“).

## Co mají karty umět
| pole | význam |
|---|---|
| `nazev` | **povinné**: správná odpověď (co to je) |
| `sada` | název sady; podle něj vznikne skupina na přehledu |
| `otazka` | otázka k obrázku (jinak „Co je to?“) |
| `popis` | vysvětlení po odpovědi |
| `hledat` | čím hledat obrázek na Wikipedii (jinak podle `nazev`) |
| `wiki`, `wikiEn` | přesný název článku na české / anglické Wikipedii |
| `alt` | další uznané odpovědi při psaní |
| `spatne` | vlastní špatné možnosti v kvízu |
| `ikona` | emoji sady |
| `bezObrazku` | `true` = čistě textová karta |
| `priorita` | `vysoká` / `střední` / `nízká` |

Hotový příklad je v souboru `moje_karty_priklad.json`. Soubor má návod i uvnitř (pole `_navod`),
takže ho můžeš rovnou poslat AI se slovy „vytvoř mi podobné karty na téma …“.

---

## ZADÁNÍ PRO AI

```text
Vytvoř kvízové karty pro mou učící appku Poznávačka a vrať je jako JSON.

TÉMA: [SEM DOPLŇ TÉMA]
POČET KARET: 20

PRAVIDLA
1. Odpověz POUZE platným JSON polem. Začni znakem [ a skonči znakem ]. Žádný úvod, žádné vysvětlování, žádné bloky se třemi zpětnými apostrofy.
2. Každá karta je objekt. Povinná pole: "kind": "karta" a "nazev" (správná odpověď = co to je; krátce, tak jak ji má žák napsat).
3. Všechny karty tématu mají stejné "sada" (název sady, např. "Dopravní značky").
4. Nepovinná pole (vynech je, pokud si nejsi jistý):
   "otazka"     otázka k obrázku, např. "Co znamená tato značka?" (bez ní se appka ptá „Co je to?“)
   "popis"      1–2 věty vysvětlení, které se ukáže po odpovědi
   "hledat"     hledaný výraz pro nalezení obrázku na Wikipedii; přidej upřesnění (např. "Eiffelova věž Paříž")
   "wiki"       přesný název článku na české Wikipedii, jen když ho znáš jistě
   "wikiEn"     přesný název článku na anglické Wikipedii, jen když ho znáš jistě
   "alt"        pole dalších přijatelných odpovědí (jiné tvary, zkratky, synonyma)
   "spatne"     pole 3 věrohodných, ale ŠPATNÝCH odpovědí pro kvíz s výběrem
   "ikona"      jedno emoji pro celou sadu (stačí u první karty)
   "bezObrazku" true, pokud má být karta jen textová (bez obrázku)
   "priorita"   "vysoká" | "střední" | "nízká"
5. Obrázky appka najde sama na Wikipedii. NEPIŠ pole "obrazek" a nevymýšlej žádné odkazy.
6. Piš česky s diakritikou. Odpovědi musí být fakticky správné a jednoznačné, karty se nesmí opakovat.
7. Uvnitř textů nepoužívej rovné uvozovky ("), použij české „ “.

PŘÍKLAD VÝSTUPU
[
 {
  "kind": "karta",
  "sada": "Dopravní značky",
  "ikona": "🚦",
  "nazev": "Zákaz vjezdu",
  "otazka": "Co znamená tato značka?",
  "popis": "Červený kruh s bílým vodorovným pruhem zakazuje vjezd všech vozidel.",
  "hledat": "Zákaz vjezdu dopravní značka",
  "spatne": [
   "Zákaz zastavení",
   "Hlavní pozemní komunikace",
   "Zákaz předjíždění"
  ]
 },
 {
  "kind": "karta",
  "sada": "Dopravní značky",
  "nazev": "Dej přednost v jízdě",
  "otazka": "Co znamená tato značka?",
  "popis": "Řidič musí dát přednost vozidlům na křižující silnici.",
  "hledat": "Dej přednost v jízdě dopravní značka",
  "alt": [
   "Dej přednost"
  ]
 },
 {
  "kind": "karta",
  "sada": "Hlavní města",
  "ikona": "🌍",
  "nazev": "Paříž",
  "otazka": "Hlavní město Francie?",
  "bezObrazku": true,
  "spatne": [
   "Lyon",
   "Marseille",
   "Brusel"
  ]
 }
]
```
