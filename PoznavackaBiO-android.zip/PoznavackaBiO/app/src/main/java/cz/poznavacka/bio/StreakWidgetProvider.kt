package cz.poznavacka.bio

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.ZoneId

class StreakWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        render(context, manager, ids)
        scheduleMidnightRefresh(context)
    }

    override fun onEnabled(context: Context) = scheduleMidnightRefresh(context)

    override fun onDisabled(context: Context) {
        context.getSystemService(AlarmManager::class.java).cancel(refreshIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_TIME_CHANGED -> {
                updateAll(context)
                scheduleMidnightRefresh(context)
            }
        }
    }

    companion object {
        private const val ACTION_REFRESH = "cz.poznavacka.bio.ACTION_REFRESH"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, StreakWidgetProvider::class.java))
            if (ids.isNotEmpty()) render(context, manager, ids)
        }

        private fun dnuLabel(n: Int) = when {
            n == 1 -> "den"
            n in 2..4 -> "dny"
            else -> "dní"
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val s = StreakStore.snapshot(context)
            val views = RemoteViews(context.packageName, R.layout.widget_streak)

            views.setTextViewText(R.id.streak_count, "🔥 ${s.streak}")
            views.setTextViewText(R.id.streak_label, "${dnuLabel(s.streak)} v řadě")
            views.setTextViewText(
                R.id.streak_status,
                if (s.doneToday) "✅ Dnes splněno" else "⏳ Dnes ještě ne"
            )
            views.setTextViewText(R.id.learned_count, "📚 ${s.learnedToday}")
            views.setTextViewText(R.id.learned_label, "nově naučeno dnes")

            views.setInt(
                R.id.widget_root, "setBackgroundResource",
                if (s.doneToday) R.drawable.widget_bg_done else R.drawable.widget_bg_pending
            )
            val textColor = context.getColor(if (s.doneToday) R.color.on_done else R.color.on_pending)
            views.setTextColor(R.id.streak_count, textColor)
            views.setTextColor(R.id.streak_label, textColor)
            views.setTextColor(R.id.streak_status, textColor)
            views.setTextColor(R.id.learned_count, textColor)
            views.setTextColor(R.id.learned_label, textColor)

            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.widget_root, open)

            manager.updateAppWidget(ids, views)
        }

        private fun refreshIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
            context, 1,
            Intent(context, StreakWidgetProvider::class.java).setAction(ACTION_REFRESH),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        /** Nepřesný budík těsně po půlnoci, aby se widget přepnul na „Dnes ještě ne". */
        fun scheduleMidnightRefresh(context: Context) {
            val at = LocalDate.now().plusDays(1)
                .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 5_000
            context.getSystemService(AlarmManager::class.java)
                .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, refreshIntent(context))
        }
    }
}
