package cz.poznavacka.bio

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader

/** Spouští poznavacka.html z assets ve WebView a posílá denní řadu do widgetu. */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView

    // Výběr souboru pro „⬆ Importovat soubor“ (JSON s památkami nebo organismy)
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        filePathCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val libCache = LibCache(applicationContext)

        // Servíruje assets přes https://appassets.androidplatform.net → localStorage drží spolehlivě
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? =
                    assetLoader.shouldInterceptRequest(request.url) ?: libCache.intercept(request.url)

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    if (request.url.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                    startActivity(Intent(Intent.ACTION_VIEW, request.url)) // externí odkazy do prohlížeče
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView,
                    callback: ValueCallback<Array<Uri>>,
                    params: WebChromeClient.FileChooserParams
                ): Boolean {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = callback
                    return try {
                        fileChooser.launch(params.createIntent())
                        true
                    } catch (e: Exception) {
                        filePathCallback = null
                        false
                    }
                }
            }
            addJavascriptInterface(StreakBridge(applicationContext), "AndroidBridge")
        }
        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        if (savedInstanceState == null) {
            webView.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/poznavacka.html")
        }
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        StreakWidgetProvider.updateAll(this) // přepočet po půlnoci, když aplikace byla na pozadí
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}

/** Most JS → Kotlin. Webová appka ho volá jako window.AndroidBridge.updateProgress(...). */
class StreakBridge(private val context: Context) {
    @JavascriptInterface
    fun updateProgress(streak: Int, lastActiveDay: String, learnedToday: Int, learnedDay: String) {
        StreakStore.save(context, streak, lastActiveDay, learnedToday, learnedDay)
        StreakWidgetProvider.updateAll(context)
    }
}
