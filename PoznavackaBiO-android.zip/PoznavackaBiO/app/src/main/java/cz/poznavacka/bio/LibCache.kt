package cz.poznavacka.bio

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Při prvním spuštění stáhne JavaScriptové knihovny z CDN (React, Tailwind, Babel) do paměti appky
 * a příště je podá odtud. Díky tomu appka nastartuje i bez internetu.
 * URL v HTML jsou připnuté na konkrétní verze, takže se obsah nemění.
 */
class LibCache(context: Context) {
    private val dir = File(context.filesDir, "libs").apply { mkdirs() }
    private val hosts = setOf("cdn.tailwindcss.com", "cdn.jsdelivr.net")

    /** Volá se z vlákna WebView (ne UI), takže blokující stahování je v pořádku. */
    fun intercept(uri: Uri): WebResourceResponse? {
        if (uri.scheme != "https" || uri.host !in hosts) return null
        val url = uri.toString()
        val file = File(dir, sha1(url))
        if (!file.exists() || file.length() < MIN_BYTES) {
            try {
                download(url, file)
            } catch (e: Exception) {
                return null // offline a není v cache → WebView to zkusí po svém
            }
        }
        return WebResourceResponse(
            "application/javascript", "utf-8", 200, "OK",
            mapOf("Access-Control-Allow-Origin" to "*"),
            FileInputStream(file)
        )
    }

    private fun download(url: String, target: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.setRequestProperty("User-Agent", "PoznavackaBiO/1.1 (Android)")
        val tmp = File(dir, target.name + ".tmp")
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            if (tmp.length() < MIN_BYTES) throw IOException("příliš malý soubor")
            if (!tmp.renameTo(target)) throw IOException("přejmenování selhalo")
        } finally {
            conn.disconnect()
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun sha1(s: String) =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private companion object {
        const val MIN_BYTES = 5_000L
    }
}
