package cz.poznavacka.bio

import android.content.Context
import java.time.LocalDate

/**
 * Ukládá poslední známý stav z webové appky:
 *  - streak         délka řady k poslednímu aktivnímu dni
 *  - lastActiveDay  poslední den s procvičením (yyyy-MM-dd), shodný formát jako dayKey() v appce
 *  - learnedToday   kolik karet přeskočilo z Nové/Neumím do Umím …
 *  - learnedDay     … a ve který den to platí
 * Co je „dnes“ a jestli řada ještě žije, se dopočítá až při vykreslení, takže je widget správně
 * i po půlnoci, když appku nikdo neotevřel.
 */
object StreakStore {
    private const val PREFS = "streak_prefs"
    private const val KEY_STREAK = "streak"
    private const val KEY_LAST = "last_active_day"
    private const val KEY_LEARNED = "learned_today"
    private const val KEY_LEARNED_DAY = "learned_day"

    data class Snapshot(val streak: Int, val doneToday: Boolean, val learnedToday: Int)

    fun save(context: Context, streak: Int, lastActiveDay: String, learned: Int, learnedDay: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_STREAK, streak)
            .putString(KEY_LAST, lastActiveDay)
            .putInt(KEY_LEARNED, learned)
            .putString(KEY_LEARNED_DAY, learnedDay)
            .apply()
    }

    fun snapshot(context: Context): Snapshot {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val streak = p.getInt(KEY_STREAK, 0)
        val last = p.getString(KEY_LAST, "") ?: ""
        val today = LocalDate.now()
        val learned = if (p.getString(KEY_LEARNED_DAY, "") == today.toString()) p.getInt(KEY_LEARNED, 0) else 0
        return when (last) {
            today.toString() -> Snapshot(streak, true, learned)
            today.minusDays(1).toString() -> Snapshot(streak, false, learned) // řada žije, dnes zbývá procvičit
            else -> Snapshot(0, false, learned)                               // vynechaný den → řada padla
        }
    }
}
