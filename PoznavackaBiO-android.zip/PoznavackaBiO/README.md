# Poznávačka BiO – Android appka s widgetem (v1.1)

## Sestavení
1. Android Studio (Koala nebo novější) → File → Open → složka `PoznavackaBiO`.
2. Počkej na Gradle sync (stáhne Gradle 8.7 a závislosti; případně přijmi nabídku aktualizace pluginu).
3. Připoj telefon (nebo emulátor) → Run ▶. APK: Build → Build APK(s).

## Widget (4×2)
Dlouze stiskni plochu → Widgety → „Poznávačka BiO" → „Denní řada".
Ukazuje: 🔥 dny v řadě · ✅/⏳ jestli je dnešek splněný · 📚 kolik karet se dnes nově naučil(a).
Poprvé otevři appku a procvič kartu, widget se tím naplní. Klepnutí na widget otevře appku.

### Co se počítá do „nově naučeno dnes"
Karta, která v režimu kartiček přeskočí z hromádky Nové/Neumím do Umím. Pokud tentýž den spadne zpět
z Umím, odečte se. Ruční přesuny („Celou sadu umím") a vstupní test se nepočítají.
Čítač se resetuje o půlnoci (data jsou v `progress.learned`, posledních 14 dní).

## Stažení části sady pro offline
Nastavení → „📥 Stažení pro offline": zaškrtni skupiny (např. Houby, Ptáci), klepni na Stáhnout.
Fotky se uloží do zařízení (Cache API) a zobrazí se i bez internetu. Jde to smazat jedním tlačítkem.
Knihovny (React, Tailwind, Babel) si appka při prvním spuštění sama uloží (`LibCache.kt`),
takže nastartuje i offline. První spuštění tedy musí proběhnout s internetem.

## Jak to funguje
- `assets/poznavacka.html` je původní soubor + úpravy: čítač `learned`, most `AndroidBridge.updateProgress`,
  sekce offline (`OfflinePanel`, `downloadOne`) a načítání stažených fotek (`offlineBlobUrl`).
- `StreakStore` pamatuje řadu, poslední aktivní den a čítač; „dnes splněno" a platnost řady se dopočítají
  při vykreslení, takže widget je správně i po půlnoci. Budík po půlnoci + 30min aktualizace ho přepnou.

## Známé limity
- Export/import JSON v Nastavení (⬇ / ⬆) ve WebView zatím nefunguje (chybí nativní uložení a výběr souboru).
- Obrázky mimo stažené skupiny a „🔄 Jiný obrázek" potřebují internet.
