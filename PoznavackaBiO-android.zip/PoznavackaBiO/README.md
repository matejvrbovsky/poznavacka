# Poznávačka BiO – Android appka s widgetem (v1.3)

## Sestavení
1. Android Studio (Koala nebo novější) → File → Open → složka `PoznavackaBiO`.
2. Počkej na Gradle sync (stáhne Gradle 8.7 a závislosti; případně přijmi nabídku aktualizace pluginu).
3. Připoj telefon (nebo emulátor) → Run ▶. APK: Build → Build APK(s).
Bez počítače jde APK postavit přes GitHub Actions (workflow `build.yml`, viz konverzace).

## Widget (4×2)
Dlouze stiskni plochu → Widgety → „Poznávačka BiO" → „Denní řada".
Ukazuje: 🔥 dny v řadě · ✅/⏳ jestli je dnešek splněný · 📚 kolik karet se dnes nově naučil(a).
Poprvé otevři appku a procvič kartu, widget se tím naplní. Klepnutí na widget otevře appku.

„Nově naučeno dnes" = karta, která v režimu kartiček přeskočí z Nové/Neumím do Umím (pád zpět se odečte;
ruční přesuny a vstupní test se nepočítají). Čítač se o půlnoci nuluje.

## Památky a slohy (nový balíček)
Nastavení → „🏛️ Památky a slohy" → „➕ Přidat ukázkové památky" (57 památek: Praha, Čechy, Morava, svět).
Na přehledu přibyde skupina „Památky a slohy" s podskupinami podle oblasti.

Režimy u památek:
- **Kartičky**: fotka → rub s názvem, místem, autorem, obdobím a znaky slohu.
- **Foto → sloh**: „Jaký je to sloh?" se 4 možnostmi (špatné jsou chronologicky nejbližší slohy).
  Po odpovědi se ukážou znaky slohu a památka. Záměny se evidují („Pleteš si s: Baroko").
- **Název → foto**, **Přiřazování**, **Psaní** (napiš název; diakritika, „sv." = „svatého" a aliasy nevadí).
- Chytrá lekce, denní opakování, řada dní, widget i offline stažení fotek fungují stejně jako u biologie.

### Vlastní památky (import JSON)
Nastavení → Import: soubor (⬆ Importovat soubor) nebo vložený text. Formát: pole objektů, viz `pamatky_ukazka.json`:

    {
      "kind": "pamatka",                 // povinné
      "nazev": "Karlův most",            // povinné
      "sloh": "gotika",                  // povinné: id nebo název slohu (viz níže)
      "misto": "Praha",
      "oblast": "praha",                 // praha | cechy | morava | svet (jinak skupina „Ostatní")
      "obdobi": "1357–1402",
      "autor": "Petr Parléř",
      "alt": ["Karlův most v Praze"],    // další přijímané odpovědi při psaní
      "wiki": "Karlův most",             // název článku na české Wikipedii (pro fotku)
      "wikiEn": "Charles Bridge",        // název článku na anglické Wikipedii (záloha)
      "poznamka": "Gotický most, sochy jsou barokní.",
      "priorita": "vysoká"               // vysoká | střední | nízká
    }

Slohy (id, přijímají se i české názvy a aliasy jako „gotický", „art nouveau", „novogotika", „empír"):
antika, romanika, gotika, renesance, baroko, klasicismus, historismus, secese, kubismus, funkcionalismus, moderna.
Položka se špatným slohem nebo bez názvu se při importu přeskočí (zpráva ukáže „přidáno X z Y").
Fotku hledá appka na Wikipedii podle `wiki`, pak podle `nazev`, pak podle `wikiEn`. Když sedí špatně, pomůže „🔄 Jiný obrázek".

## Moje kvízy: karty na cokoli (záložka 🧩 Karty)
Karta = otázka + správná odpověď („co to je“). Obrázek se najde sám na Wikipedii. Sady vznikají podle pole `sada`
a objeví se na přehledu ve skupině „Moje kvízy“. Režimy: kartičky, kvíz (výběr odpovědi), odpověď → foto, přiřazování,
psaní odpovědi; chytrá lekce, řada dní, widget a offline stažení fotek fungují stejně jako jinde.

Tři cesty, jak karty přidat:
1. **Pomocí AI** (nejrychlejší): napiš téma → „📋 Zkopírovat zadání pro AI“ → vlož do ChatGPT / Claude / Gemini →
   odpověď vlož do appky a „⬆ Importovat karty“. AI nemusíš nic vysvětlovat, formát je v zadání. Import zvládne i JSON
   v bloku ```json, text okolo, čárku navíc a české i anglické názvy polí.
2. **Ručně**: formulář „✍️ Přidat kartu ručně“ (stačí odpověď; náhled ukáže, jaký obrázek se najde).
3. **Souborem**: „📄 Importovat soubor .json“. Vzor je `moje_karty_priklad.json` (návod pro AI je v něm i uvnitř, v poli `_navod`).

Celý návod a zadání pro AI je v `navod_pro_ai.md`.

Pole karty (povinné je jen `nazev`):

    {
      "kind": "karta",
      "sada": "Dopravní značky",                 // název sady
      "nazev": "Zákaz vjezdu",                   // POVINNÉ: správná odpověď
      "otazka": "Co znamená tato značka?",       // jinak „Co je to?“
      "popis": "Červený kruh s bílým pruhem…",   // ukáže se po odpovědi
      "hledat": "Zákaz vjezdu dopravní značka",  // čím hledat obrázek (jinak nazev)
      "wiki": "…", "wikiEn": "…",                // přesný název článku na cs / en Wikipedii
      "alt": ["Zákaz vjezdu všech vozidel"],     // další uznané odpovědi při psaní
      "spatne": ["Zákaz zastavení", "…"],        // vlastní špatné možnosti v kvízu
      "ikona": "🚦",                             // emoji sady
      "bezObrazku": false,                       // true = čistě textová karta
      "priorita": "střední"
    }

Obrázek: nejdřív přesný článek (`wiki` nebo `nazev`), pak fulltext Wikipedie (`hledat` nebo `nazev`), pak anglicky (`wikiEn`).
Odkaz `obrazek` (jen https://) lze zadat ručně, od AI se nežádá. Když je obrázek špatný, pomůže „🔄 Jiný obrázek“
nebo upřesnit `hledat`. Textové karty (`bezObrazku`) se v režimech s fotkami přeskakují.

## Stažení části sady pro offline
Nastavení → „📥 Stažení pro offline": zaškrtni skupiny (i oblasti památek), klepni na Stáhnout. Fotky se uloží
do zařízení a zobrazí se i bez internetu. Knihovny (React, Tailwind, Babel) si appka při prvním spuštění uloží sama
(`LibCache.kt`), takže pak nastartuje offline. První spuštění musí proběhnout s internetem.

## Známé limity
- Export JSON v Nastavení (⬇) ve WebView zatím nefunguje (chybí nativní uložení souboru). Import souboru funguje.
- Obrázky mimo stažené skupiny a „Jiný obrázek" potřebují internet.
